chrome.runtime.onMessage.addListener((t,a,o)=>{if(t.action==="summarizeSelection")l(t.text);else if(t.action==="summarizePage"){const e=s();l(e)}else if(t.action==="getSelectedText"){const e=window.getSelection().toString().trim();o({selectedText:e})}else if(t.action==="getPageText"){const e=s();o({pageText:e})}return!0});function s(){document.querySelectorAll("script, style").forEach(e=>e.remove());const a=["article","main",'[role="main"]',".content",".post",".article","body"];let o="";for(const e of a){const r=document.querySelector(e);if(r){o=r.innerText;break}}return o.replace(/\s+/g," ").replace(/\n\s*\n/g,`
`).trim().substring(0,5e3)}function l(t,a){const o=document.getElementById("tldr-pro-popup");o&&o.remove();const e=document.createElement("div");e.id="tldr-pro-popup",e.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    width: 350px;
    max-height: 500px;
    background: white;
    border: 2px solid #3498db;
    border-radius: 10px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    z-index: 10000;
    padding: 20px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    overflow-y: auto;
  `,e.innerHTML=`
    <div style="margin-bottom: 15px;">
      <h3 style="margin: 0 0 10px 0; color: #2c3e50; font-size: 18px;">TLDR-Pro Summary</h3>
      <button id="tldr-close-btn" style="
        position: absolute;
        top: 10px;
        right: 10px;
        background: #e74c3c;
        color: white;
        border: none;
        border-radius: 50%;
        width: 25px;
        height: 25px;
        cursor: pointer;
        font-size: 14px;
      ">×</button>
    </div>
    
    <div style="margin-bottom: 15px;">
      <label style="display: block; margin-bottom: 5px; font-weight: 500;">Word Count:</label>
      <input id="tldr-word-count" type="number" value="100" min="10" max="500" style="
        width: 80px;
        padding: 5px;
        border: 1px solid #bdc3c7;
        border-radius: 4px;
      ">
    </div>
    
    <button id="tldr-summarize-btn" style="
      width: 100%;
      background: #3498db;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      margin-bottom: 15px;
    ">Generate Summary</button>
    
    <div id="tldr-summary-result" style="
      min-height: 60px;
      padding: 10px;
      background: #f8f9fa;
      border: 1px solid #e9ecef;
      border-radius: 6px;
      font-size: 14px;
      line-height: 1.5;
    ">Click "Generate Summary" to create a summary...</div>
  `,document.body.appendChild(e),document.getElementById("tldr-close-btn").addEventListener("click",()=>{e.remove()}),document.getElementById("tldr-summarize-btn").addEventListener("click",()=>{const r=document.getElementById("tldr-word-count").value,n=document.getElementById("tldr-summarize-btn"),i=document.getElementById("tldr-summary-result");n.textContent="Summarizing...",n.disabled=!0,i.textContent="Processing your request...",chrome.runtime.sendMessage({action:"summarize",endpoint:"/text",data:{text:t,word_count:parseInt(r)}},d=>{n.textContent="Generate Summary",n.disabled=!1,d&&d.success?i.textContent=d.data.summary:(i.textContent="Error: "+(d?.error||"Failed to generate summary"),i.style.color="#e74c3c")})})}const c=document.createElement("style");c.textContent=`
  #tldr-pro-popup * {
    box-sizing: border-box;
  }
  
  #tldr-pro-popup button:hover:not(:disabled) {
    opacity: 0.9;
  }
  
  #tldr-pro-popup button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;document.head.appendChild(c);
